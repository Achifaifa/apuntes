public class Ejercicios  {
  public static void main(String[] args) {
	  	ejercicio1();
  }

  public static void ejercicio1(){
	    int[] a = {8, 6, 9, 5, 4, 10, 1, 3};
	    int[] b = new int[8];

	    b[0] = 8;
	    b[1] = 6;
	    b[2] = 9;
	    b[3] = 5;
	    b[4] = 4;
	    b[5] = 10;
	    b[6] = 1;
	    b[7] = 3;
	    
	    printTable(a);
	    Algoritmos.insertionSort(a);
	    printTable(a);	
  }
	  
  public static void printTable(int a[]){
    System.out.print("a={");
    for (int i=0; i < a.length; i++)
      System.out.print(a[i]+", ");
    System.out.println("}");    
  }

  public static void printTable(Object a[]){
	System.out.print("a={");
	for (int i=0; i < a.length; i++)
	   System.out.print(a[i]+", ");
	System.out.println("}");    
  }
}