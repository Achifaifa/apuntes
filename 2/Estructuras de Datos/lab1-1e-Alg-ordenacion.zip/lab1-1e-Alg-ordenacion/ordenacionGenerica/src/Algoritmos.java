import java.util.Comparator;

public class Algoritmos  {
  public Algoritmos() { 
  }


  public static void insertionSort (int a[]) {
    for(int p=1; p < a.length; p++) {// recorre desde p hasta fin del array
         int tmp=a[p];
          int j;
          for(j=p; j>0 && tmp < a[j-1]; j--) { // recorre desde p hasta principio del array
               a[j]=a[j-1]; // desplazo hacia la drcha lo elementos del vector mayores que tmp
          }
          a[j]=tmp; // inserto tmp en la posici�n en la que se para j (cuando dejo de desplazar elementos)
    }
  }

  public static void selectionSort (int a[]) {
    for(int i=0; i < a.length-1; i++) {    // recorre todo el array
      int current = a[i]; // selecciona un elemento
      int k=i;
      for(int j=i+1; j < a.length; j++) { // recorre desde la posici�n siguiente al seccionado 
                       // hasta el final del array  
        if (current >a[j]){ // compara el seleccionado con los elementos del subarray restante
            k=j;		 // se queda con la posici�n del mas peque�o
           current=a[j];       // y su contenido
        }
      }
      a[k]=a[i]; // guarda el elemento seleccionado en el hueco donde estaba el mas peque�o
      a[i]=current; // guarda el elemento mas peque�o en el hueco donde estaba el seleccionado
    }
  }

  public static <T extends Comparable<T>> void insertionSort (T a[]) {
  	for(int p=1; p < a.length; p++) {// recorre desde p hasta fin del array
  	      T tmp=a[p];
          int j;
          // recorre desde p hasta el inicio del array
  	      for(j=p; j>0 && (tmp.compareTo(a[j-1])<0); j--) {		   	
  	    	  a[j]=a[j-1]; // desplazo hacia la derecha los elementos del vector mayores que tmp
  	      }
  	      a[j]=tmp; // inserto tmp en la posici�n en la que se para j (cuando dejamos de desplazar elementos)
  	}
  }

  public static <T extends Comparable<T>> void selectionSort (T a[]) {
	    for(int i=0; i < a.length-1; i++) {    // recorre todo el array
	      T current = a[i]; // selecciona un elemento
	      int k=i;
	      for(int j=i+1; j < a.length; j++) { // recorre desde la posici�n siguiente al seccionado 
	                       // hasta el final del array  
	        if (current.compareTo(a[j]) > 0){ // compara el seleccionado con los elementos del subarray restante
	            k=j;		 // se queda con la posici�n del mas peque�o
	            current=a[j];       // y su contenido
	        }
	      }
	      a[k]=a[i]; // guarda el elemento seleccionado en el hueco donde estaba el mas peque�o
	      a[i]=current; // guarda el elemento mas peque�o en el hueco donde estaba el seleccionado
	    }
  }

  public static <T> void insertionSort (T a[], Comparator<T> comp) {
	  	for(int p=1; p < a.length; p++) {// recorre desde p hasta fin del array
	  	      T tmp=a[p];
	          int j;
	          // recorre desde p hasta el inicio del array
	  	      for(j=p; j>0 && (comp.compare(tmp, a[j-1])<0); j--) {		   	
	  	    	  a[j]=a[j-1]; // desplazo hacia la derecha los elementos del vector mayores que tmp
	  	      }
	  	      a[j]=tmp; // inserto tmp en la posici�n en la que se para j (cuando dejamos de desplazar elementos)
	  	}
   }
  
  public static <T> void selectionSort (T a[], Comparator<T> comp) {
	    for(int i=0; i < a.length-1; i++) {    // recorre todo el array
	      T current = a[i]; // selecciona un elemento
	      int k=i;
	      for(int j=i+1; j < a.length; j++) { // recorre desde la posici�n siguiente al seccionado 
	                       // hasta el final del array  
	        if (comp.compare(current, a[j]) > 0){ // compara el seleccionado con los elementos del subarray restante
	            k=j;		 // se queda con la posici�n del mas peque�o
	            current=a[j];       // y su contenido
	        }
	      }
	      a[k]=a[i]; // guarda el elemento seleccionado en el hueco donde estaba el mas peque�o
	      a[i]=current; // guarda el elemento mas peque�o en el hueco donde estaba el seleccionado
	    }
}
}