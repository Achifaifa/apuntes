
public class Programa  {

  public static void main(String[] args) {
    int a[] = new int[8];
/*
    for (int i=0; i < 8; i++)
      a[i] = (int) (Math.random()*100);
*/
//  int a[]={85, 24, 63, 45, 17, 31, 96, 50};
    a[0] = 85;
    a[1] = 24;
    a[2] = 63;
    a[3] = 45;
    a[4] = 17;
    a[5] = 31;
    a[6] = 96;
    a[7] = 50;
    printTable(a);
    MergeSort.mergeSort(a);
    printTable(a);
  }

  public static void printTable(int a[]){
    System.out.print("a={");
    for (int i=0; i < a.length; i++)
      System.out.print(a[i]+", ");
    System.out.println("}");    
  }
}